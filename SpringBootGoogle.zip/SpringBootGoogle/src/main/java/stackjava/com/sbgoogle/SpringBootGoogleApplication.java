package stackjava.com.sbgoogle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootGoogleApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootGoogleApplication.class, args);
	}
}
